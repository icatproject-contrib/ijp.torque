ids.storage_file: File Storage plugin for ICAT Data Service
------------------------------------------------------------

General installation instructions are at http://code.google.com/p/icatproject/wiki/Installation

Specific installation instructions are at http://www.icatproject.org/mvn/site/ids/storage_file/1.0.0/installation.html

All documentation on ids.storage_file may be found at http://www.icatproject.org/mvn/site/ids/storage_file/1.0.0