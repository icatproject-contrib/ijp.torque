ids.server: Server part of ICAT Data Server (IDS)
-------------------------------------------------

General installation instructions are at http://www.icatproject.org/installation/component

Specific installation instructions are at http://www.icatproject.org/mvn/site/ids/server/1.0.1/installation.html

All documentation on ids.server may be found at http://www.icatproject.org/mvn/site/ids/server/1.0.1