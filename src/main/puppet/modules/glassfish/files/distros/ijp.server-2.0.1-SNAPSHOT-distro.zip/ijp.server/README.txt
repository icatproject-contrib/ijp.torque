ijp_portal: IJP Webapp
----------------------

General installation instructions are at http://code.google.com/p/icatproject/wiki/Installation

Specific installation instructions are at http://www.icatproject.org/mvn/site/ijp/server/2.0.1-SNAPSHOT/installation.html

All documentation on ids.server may be found at http://www.icatproject.org/mvn/site/ijp/server/2.0.1-SNAPSHOT