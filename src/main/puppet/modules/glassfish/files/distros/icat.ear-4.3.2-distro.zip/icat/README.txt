ICAT
----

General installation instructions are at http://www.icatproject.org/installation/component

Specific installation instructions are at http://www.icatproject.org/mvn/site/icat/4.3.2/icat.ear/installation.html

All documentation on ICAT may be found at http://www.icatproject.org/mvn/site/icat/4.3.2