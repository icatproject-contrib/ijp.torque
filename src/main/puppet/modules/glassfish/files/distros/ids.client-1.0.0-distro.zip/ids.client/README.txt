ids.client: Clients for ICAT Data Server (IDS)
-------------------------------------------------

General installation instructions are at http://www.icatproject.org/installation/component

Specific installation instructions are at http://www.icatproject.org/mvn/site/ids/client/1.0.0/installation.html

All documentation on ids.client may be found at http://www.icatproject.org/mvn/site/ids/client/1.0.0