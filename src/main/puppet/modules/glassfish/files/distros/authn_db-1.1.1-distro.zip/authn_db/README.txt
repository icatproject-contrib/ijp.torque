authn_db
--------

General installation instructions are at http://code.google.com/p/icatproject/wiki/Installation

Specific installation instructions are at http://www.icatproject.org/mvn/site/authn_db/1.1.1/installation.html

All documentation on authn_db may be found at http://www.icatproject.org/mvn/site/authn_db/1.1.1